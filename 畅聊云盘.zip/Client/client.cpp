#include "client.h"
#include "ui_client.h"
#include "protocol.h"
#include "index.h"
#include "friend.h"

#include <QFile>
#include <QDebug>
#include <QHostAddress>
#include <QMessageBox>


Client::Client(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Client)
{
    ui->setupUi(this);
    loadConfig();

    rh = new ResHander;
    //关联连接成功的信号和处理信号的槽函数
    connect(&m_tcpSocket,&QTcpSocket::connected,this,&Client::showConnect);
    connect(&m_tcpSocket,&QTcpSocket::readyRead,this,&Client::recvMsg);


    //调用connectToHost连接到服务器
    m_tcpSocket.connectToHost(QHostAddress(m_strIP),m_usPort);
}

Client::~Client()
{
    delete ui;
}

//加载配置
void Client::loadConfig()
{
    //新建一个QFile对象
    QFile file(":/client.config");//固定冒号开头
    //以只读打开文件
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray baData = file.readAll();//读出配置文件中的所有东西——baData
        QString strData = QString(baData);//将strData转成字符串类型
        QStringList strList = strData.split("\r\n");//split：将strData字符串按照\r\n进行拆分
        m_strIP = strList.at(0);//拆分出IP地址
        m_usPort = strList.at(1).toUShort();//拆分出端口号
        qDebug() << "ip:" << m_strIP << "port:" << m_usPort;
        file.close();//关闭文件
    }
    else
    {
        qDebug() << "打开配置失败";
    }

}

Client &Client::getInstance()   //返回静态局部对象的引用 因为静态局部变量线程安全
{
    static Client instance;
    return instance;
}

QTcpSocket &Client::getSocket()
{
    return m_tcpSocket;
}

PDU *Client::readPDU()
{
    uint uiPDULen = 0;
    //读取协议总长度uiPDULen
    m_tcpSocket.read((char*)&uiPDULen,sizeof(uint));
    uint uiMsgLen = uiPDULen - sizeof(PDU);
    PDU* pdu = mkPDU(uiMsgLen);
    //读取协议除了协议总长度以外的内容
    m_tcpSocket.read((char*)pdu + sizeof(uint),uiPDULen - sizeof(uint));
    qDebug() << "recvMsg 消息类型：" <<pdu->uiMsgType
             << "参数内容1：" << pdu->caData
             << "参数内容2：" << pdu->caData + 32
             << "消息内容：" << pdu->caMsg;
    return pdu;
}

void Client::handlePDU(PDU *pdu)
{

//    qDebug() << "handlePDU 消息类型：" <<pdu->uiMsgType
//             << "参数内容1：" << pdu->caData
//             << "参数内容2：" << pdu->caData + 32
//             << "消息内容：" << pdu->caMsg;
    //客户端接收响应
    switch (pdu->uiMsgType)
    {

        //注册
        case ENUN_MSG_TYPE_REGIST_RESPEND:
        {
            rh->regist(pdu);
                break;
        }

        //登录
        case ENUN_MSG_TYPE_REGIST_RESPEND_login:
        {
            rh->login(pdu);
              break;
        }


        //查找用户
        case ENUN_MSG_TYPE_FIND_USER_RESPEND:
        {
            rh->findUser(pdu);
            break;
        }

        case ENUN_MSG_TYPE_ONLINE_USER_RESPEND:
        {
            rh->onlineUser(pdu);
            break;
        }

        //添加好友
        case ENUN_MSG_TYPE_ADD_USER_RESPEND:
        {
            rh->addUser(pdu);
            break;
        }

        //是否同意好友请求
        case ENUN_MSG_TYPE_ADD_USER_REQUEST:
        {
            rh->addUserRequest(pdu);
            break;
        }

        //同意好友请求
        case ENUN_MSG_TYPE_AGREE_USER_RESPEND:
        {
            rh->addUserAgreeRequest(pdu);
            break;
        }

        //刷新在线好友
        case ENUN_MSG_TYPE_FLUSH_ONLINE_USER_RESPEND:
        {
            rh->flushOnlineUser(pdu);
            break;
        }

        //删除好友
        case ENUN_MSG_TYPE_DELETE_USER_RESPEND:
        {
            rh->deleteUser(pdu);
            break;
        }

        //聊天
        case ENUN_MSG_TYPE_CHAT_REQUEST:
        {
            rh->chat(pdu);
            break;
        }

        //新建文件夹
        case ENUN_MSG_TYPE_MKDIR_RESPEND:
        {
            rh->mkDir(pdu);
            break;
        }

        //刷新文件夹
        case ENUN_MSG_TYPE_FLUSH_FILE_RESPEND:
        {
            rh->flushFile(pdu);
            break;
        }

        //删除文件夹
        case ENUN_MSG_TYPE_DELETE_FILEDIR_RESPEND:
        {
            rh->deleteFileDir(pdu);
            break;
        }

        //重命名文件
        case ENUN_MSG_TYPE_RENAME_FILE_RESPEND:
        {
            rh->renameFile(pdu);
            break;
        }

        //移动文件
        case ENUN_MSG_TYPE_MOVE_FILE_RESPEND:
        {
            rh->moveFile(pdu);
            break;
        }

        //上传文件
        case ENUN_MSG_TYPE_UPLOAD_FILE_RESPEND:
        {
            rh->uploadFile(pdu);
            break;
        }

        //上传文件数据
        case ENUN_MSG_TYPE_UPLOAD_FILE_DATA_RESPEND:
        {
            rh->uploadFileData(pdu);
            break;
        }

        //分享文件
        case ENUN_MSG_TYPE_SHARE_FILE_RESPEND:
        {
            rh->shareFile();
            break;
        }

        //发送文件请求
        case ENUN_MSG_TYPE_SHARE_FILE_REQUEST:
        {
            rh->shareFileRequst(pdu);
            break;
        }

        //同意文件接收
        case ENUN_MSG_TYPE_SHARE_FILE_ARGEE_RESPEND:
        {
            rh->shareFileAgree(pdu);
            break;
        }
            default:
                break;

    }
    free(pdu);
    pdu = NULL;
}

void Client::sendPDU(PDU *pdu)
{
    qDebug() << "recvMsg 消息类型：" <<pdu->uiMsgType
             << "参数内容1：" << pdu->caData
             << "参数内容2：" << pdu->caData + 32
             << "消息内容：" << pdu->caMsg;
    //发送pdu
    m_tcpSocket.write((char*)pdu,pdu->uiPDUlen);//传协议的总长度
    free(pdu);
    pdu = NULL;
}


void Client::showConnect()
{
    qDebug() << "连接服务器成功";
}

void Client::recvMsg()
{
    qDebug() << "\nrecvMsg 接收的消息长度" << m_tcpSocket.bytesAvailable();
    //定义一个buffer记录半包
    QByteArray data = m_tcpSocket.readAll();
    buffer.append(data);
    //循环处理粘包问题
    while(buffer.size() >= int(sizeof(PDU)))
    {
        //判断buffer里是否含有一个完整的PDU结构体
        PDU* pdu = (PDU*)buffer.data();
        //半包
        if(buffer.size() < int(pdu->uiPDUlen))
        {
            break;
        }
        PDU* pdun = mkPDU(pdu->uiMsglen);
        memcpy(pdun,pdu,pdu->uiPDUlen);
        handlePDU(pdun);
        //将处理完的数据从buffer中移除
        buffer.remove(0,pdu->uiPDUlen);
    }
}

void Client::on_register_2_clicked()
{
    QString strName = ui->name_LE->text();    //获取用户名
    QString strPwd = ui->pwd_LE->text();        //获取用户名
    if(strName.isEmpty() ||
       strPwd.isEmpty() ||
       strName.toStdString().size() > 32 ||
       strPwd.toStdString().size() > 32)
    {
        QMessageBox::information(this,"注册","用户名或密码不规范");//弹窗提醒
        return;
    }
    //构建并初始化pdu
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUN_MSG_TYPE_REGIST_REQUEST;  //发送请求
    //将用户名密码放入cadata中
    memcpy(pdu->caData,strName.toStdString().c_str(),32);
    memcpy(pdu->caData + 32,strPwd.toStdString().c_str(),32);
    //write：发送pdu
    sendPDU(pdu);
}

void Client::on_Login_clicked()
{
    QString strName = ui->name_LE->text();
    QString strPwd = ui->pwd_LE->text();
    if(strName.isEmpty() ||
       strPwd.isEmpty() ||
       strName.toStdString().size() > 32 ||
       strPwd.toStdString().size() > 32)
    {
        QMessageBox::information(this,"登录","用户不存在或者密码错误");
        return;
    }
    //构建并初始化pdu
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUN_MSG_TYPE_REGIST_REQUEST_login;
    m_strLoginName = strName;
    memcpy(pdu->caData,strName.toStdString().c_str(),32);
    memcpy(pdu->caData + 32,strPwd.toStdString().c_str(),32);
    //write：发送pdu
    sendPDU(pdu);
}


















