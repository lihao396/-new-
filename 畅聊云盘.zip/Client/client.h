#ifndef CLIENT_H
#define CLIENT_H

#include "protocol.h"
#include "reshander.h"

#include <QTcpSocket>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Client; }
QT_END_NAMESPACE

class Client : public QWidget
{
    Q_OBJECT

public:

    ~Client();
    //加载配置文件
    void loadConfig();
    //单例模式 获取实例 定义静态函数
    static Client& getInstance();//&：不会有拷贝构造

    QString m_strLoginName; //当前登录用户名
    QTcpSocket& getSocket();

    PDU* readPDU();
    void handlePDU(PDU* pdu);//处理消息类型
    ResHander* rh;
    void sendPDU(PDU* pdu);//发送请求
    QByteArray buffer;

public slots:
    void showConnect();
    void recvMsg();     //客户端接收函数
private slots:

    void on_register_2_clicked();

    void on_Login_clicked();

private:
    //实现单例模式 私有化构造函数、删除拷贝构造和赋值运算符
    Client(QWidget *parent = nullptr);
    Client(const Client& instance) = delete;
    Client& operator=(const Client&) = delete;
    Ui::Client *ui;
    //ip和端口号
    QString m_strIP;
    quint16 m_usPort;
    //用于连接服务器的socket
    QTcpSocket m_tcpSocket;

};
#endif // CLIENT_H
