#include "client.h"
#include "file.h"
#include "ui_file.h"

#include <QInputDialog>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>


File::File(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::File)
{
    ui->setupUi(this);
    shareFile = new ShareFile;
    curPath = QString("./filesys/%1").arg(Client::getInstance().m_strLoginName);
    userPath = curPath;
    flushFile();
    uploadFile = false;
}

File::~File()
{
    delete ui;
    delete shareFile;
}

//刷新文件夹
void File::flushFile()
{
    PDU* pdu = mkPDU(curPath.toStdString().size()+1);
    pdu->uiMsgType = ENUN_MSG_TYPE_FLUSH_FILE_REQUEST;
    memcpy(pdu->caMsg,curPath.toStdString().c_str(),curPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);
}

//更新文件列表框
void File::updateFileList(QList<FileInfo *> pFileInfoList)
{
    foreach(FileInfo* pFileInfo,m_pFileInfoList)
    {
        delete pFileInfo;
    }

    m_pFileInfoList.clear();
    m_pFileInfoList = pFileInfoList;
    ui->file_LW->clear();

    foreach(FileInfo* pFileInfo,pFileInfoList)
    {
        QListWidgetItem* pItem = new QListWidgetItem;
        pItem->setText(pFileInfo->caFileName);
        if(pFileInfo->uiFileType == 0)
        {
            pItem->setIcon(QIcon(QPixmap(":/mkDir.png")));
        }
        else if(pFileInfo->uiFileType == 1)
        {
            pItem->setIcon(QIcon(QPixmap(":/file.png")));
        }

        qDebug() << "updateFileList pFileInfo caFileName" << pFileInfo->caFileName;

        ui->file_LW->addItem(pItem);
    }
}

void File::myUploadFile()
{
    QFile file(uploadFilePath);
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this,"上传文件","打开文件失败");
        return;
    }
    uploadFile = true;
    qint64 ret = 0;
    PDU* datapdu = mkPDU(4096);
    datapdu->uiMsgType = ENUN_MSG_TYPE_UPLOAD_FILE_DATA_REQUEST;
    while(true)
    {
        ret = file.read(datapdu->caMsg,4096);
        if(ret == 0)
        {
            break;
        }
        if(ret < 0)
        {
            QMessageBox::warning(this,"上传文件","上传文件失败：读取失败");
            break;
        }
        datapdu->uiMsglen = ret;
        datapdu->uiPDUlen = ret + sizeof(PDU);
        Client::getInstance().getSocket().write((char*)datapdu,datapdu->uiPDUlen);
    }
    uploadFile = false;
    file.close();
    free(datapdu);
    datapdu = NULL;
}

//新建文件夹
void File::on_mkDir_PB_clicked()
{
    QString newDirName = QInputDialog::getText(this,"新建文件夹","新建文件夹名字");
    qDebug() << "newDirName:" << newDirName;
    if(newDirName.isEmpty() || newDirName.toStdString().size() > 32)
    {
        QMessageBox::information(this,"新建文件夹","新建文件夹名字不规范");
        return;
    }
    PDU* pdu = mkPDU(curPath.toStdString().size() + 1);
    pdu->uiMsgType = ENUN_MSG_TYPE_MKDIR_REQUEST;
    memcpy(pdu->caData,newDirName.toStdString().c_str(),32);
    memcpy(pdu->caMsg,curPath.toStdString().c_str(),curPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);
}

void File::on_flushFile_PB_clicked()
{
    flushFile();
}

//删除文件夹
void File::on_delDirFile_PB_clicked()
{
    QListWidgetItem* dItem = ui->file_LW->currentItem(); //获取当前列表框文件夹
    if(dItem == NULL)   //没有选择要删除的文件夹
    {
        QMessageBox::warning(this,"删除文件夹","未选择要删除的文件夹");
        return;
    }

    QString delName = dItem->text();
    foreach(FileInfo* pFileInfo,m_pFileInfoList)
    {
        if(pFileInfo->caFileName == delName && pFileInfo->uiFileType != 0)
        {
            QMessageBox::information(this,"删除文件夹","删除的不是文件夹");
            return;
        }
    }
    int ret = QMessageBox::question(this,"删除文件夹",QString("是否删除当前文件夹 %1 ").arg(delName));
    if(ret != QMessageBox::Yes)
    {
        return;
    }
    QString strPath = QString("%1/%2").arg(curPath).arg(delName);
    PDU* pdu = mkPDU(strPath.toStdString().size()+1);
    pdu->uiMsgType = ENUN_MSG_TYPE_DELETE_FILEDIR_REQUEST;
    memcpy(pdu->caMsg,strPath.toStdString().c_str(),strPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);
}

//重命名
void File::on_renameFile_PB_clicked()
{
    QListWidgetItem* dItem = ui->file_LW->currentItem(); //获取当前列表框文件
    if(dItem == NULL)   //没有选择要重命名的文件
    {
        QMessageBox::information(this,"重命名文件","未选择要重命名的文件");
        return;
    }

    QString oldName = dItem->text();

    QString newName = QInputDialog::getText(this,"重命名文件","重命名文件名字");
    if(newName.isEmpty() || newName.toStdString().size() > 32)
    {
        QMessageBox::information(this,"重命名文件","重命名文件名字不规范");
        return;
    }
    PDU* pdu = mkPDU(curPath.toStdString().size() + 1);
    pdu->uiMsgType = ENUN_MSG_TYPE_RENAME_FILE_REQUEST;
    memcpy(pdu->caData,oldName.toStdString().c_str(),32);
    memcpy(pdu->caData+32,newName.toStdString().c_str(),32);
    memcpy(pdu->caMsg,curPath.toStdString().c_str(),curPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);
}

void File::on_file_LW_itemDoubleClicked(QListWidgetItem *item)
{
    QString dirName = item->text();
    foreach(FileInfo* pFileInfo,m_pFileInfoList)
    {
        if(pFileInfo->caFileName == dirName && pFileInfo->uiFileType != 0)
        {
            QMessageBox::information(this,"进入文件夹","进入的不是文件夹");
            return;
        }
    }

    curPath = QString("%1/%2").arg(curPath).arg(dirName);
    flushFile();
}

//返回上一级
void File::on_return_PB_clicked()
{
    if(curPath == userPath)
    {
        QMessageBox::warning(this,"返回上一级","已在根目录");
        return;
    }

    int index = curPath.lastIndexOf('/');
    curPath.remove(index,curPath.size() - index);
    flushFile();
}

//移动文件
void File::on_mvFile_PB_clicked()
{
    if(ui->mvFile_PB->text() == "移动文件")
    {
        QListWidgetItem* pItem = ui->file_LW->currentItem();
        if(pItem == NULL)
        {
            QMessageBox::information(this,"移动文件","请选择要移动的文件");
            return;
        }
        QMessageBox::information(this,"移动文件","请选择要移动到的目录");

        moveFileName = pItem->text();
        moveFilePath = curPath + '/' + moveFileName;
        ui->mvFile_PB->setText("确认/取消");
        return;
    }

    QString tarPath;
    QString boxMsg;

    QListWidgetItem* pItem = ui->file_LW->currentItem();
    if(pItem == NULL)   //用户没有点击目录
    {
        tarPath = curPath + '/' + moveFileName;
        boxMsg = "是否移动到当前目录下";
    }
    else
    {
        QString dirName = pItem->text();
        foreach(FileInfo* pFileInfo,m_pFileInfoList)
        {
            if(pFileInfo->caFileName == dirName && pFileInfo->uiFileType != 0)
            {
                QMessageBox::information(this,"进入文件夹","进入的不是文件夹");
                return;
            }
        }
        tarPath = curPath + '/' + dirName + '/' + moveFileName;
        boxMsg = QString("是否移动到 %1 目录下").arg(dirName);
    }

    int res = QMessageBox::information(this,"移动文件",boxMsg,"确认","取消");
    ui->mvFile_PB->setText("移动文件");

    if(res != 0)
    {
        return;
    }
    int srcLen = moveFilePath.toStdString().size();
    int tarLen = tarPath.toStdString().size();
    PDU* pdu = mkPDU(srcLen + tarLen + 1);
    pdu->uiMsgType = ENUN_MSG_TYPE_MOVE_FILE_REQUEST;
    memcpy(pdu->caData,&srcLen,sizeof(int));
    memcpy(pdu->caData + 32,&tarLen,sizeof(int));
    memcpy(pdu->caMsg,moveFilePath.toStdString().c_str(),srcLen);
    memcpy(pdu->caMsg + srcLen,tarPath.toStdString().c_str(),tarLen);
    Client::getInstance().sendPDU(pdu);
}

//上传文件
void File::on_upload_PB_clicked()
{
    if(uploadFile)
    {
        QMessageBox::warning(this,"上传文件","已有文件正在上传");
        return;
    }
    uploadFilePath.clear();
    uploadFilePath = QFileDialog::getOpenFileName();    //获取上传路径名字
    qDebug() << "on_upload_PB_clicked uploadFilePath" << uploadFilePath;
    if(uploadFilePath.isEmpty())    //如果没有用户没有选择文件路径
    {
        return;
    }

    PDU* pdu = mkPDU(curPath.toStdString().size() + 1);
    pdu->uiMsgType = ENUN_MSG_TYPE_UPLOAD_FILE_REQUEST;

    //从路径中取出文件名、大小、当前路径
    int index = uploadFilePath.lastIndexOf('/');    //取出文件名 找到路径中最后一个'/'
    QString fileName = uploadFilePath.right(uploadFilePath.size() - index - 1);
    QFile file(uploadFilePath);
    qint64 fileSize = file.size();  //计算file(uploadFilePath)文件的大小

    //将文件名、大小、当前路径发送给服务器
    memcpy(pdu->caData,fileName.toStdString().c_str(),32);
    memcpy(pdu->caData + 32,&fileSize,sizeof(qint64));
    memcpy(pdu->caMsg,curPath.toStdString().c_str(),curPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);

}

void File::on_shareFile_PB_clicked()
{
    QListWidgetItem* pItem = ui->file_LW->currentItem();    //获取file列表框中的文件
    if(pItem == NULL)   //判断是否选择了要分享的文件
    {
        QMessageBox::information(this,"分享文件","未选择要分享的文件");
        return;
    }
    shareFile->updateOnlineFriend_LW(); //填充分享界面中的好友列表
    shareFileName = pItem->text();
    if(shareFile->isHidden())   //判断分享文件界面是否隐藏
    {
        shareFile->show();  //显示隐藏界面
    }
}
