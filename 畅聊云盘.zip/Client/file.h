#ifndef FILE_H
#define FILE_H

#include "protocol.h"
#include "sharefile.h"

#include <QWidget>
#include <qlistwidget.h>

namespace Ui {
class File;
}

class File : public QWidget
{
    Q_OBJECT

public:
    explicit File(QWidget *parent = nullptr);
    ~File();
    QString curPath;    //当前路径
    QString userPath;   //用户路径
    void flushFile();   //刷新文件
    QList<FileInfo*> m_pFileInfoList;
    void updateFileList(QList<FileInfo*> pFileInfoList);

    //移动文件
    QString moveFileName;
    QString moveFilePath;

    //上传文件
    QString uploadFilePath;
    bool uploadFile;
    void myUploadFile();
    ShareFile* shareFile;
    QString shareFileName;

private slots:
    void on_mkDir_PB_clicked();

    void on_flushFile_PB_clicked();

    void on_delDirFile_PB_clicked();

    void on_renameFile_PB_clicked();

    void on_file_LW_itemDoubleClicked(QListWidgetItem *item);

    void on_return_PB_clicked();

    void on_mvFile_PB_clicked();

    void on_upload_PB_clicked();

    void on_shareFile_PB_clicked();

private:
    Ui::File *ui;
};

#endif // FILE_H
