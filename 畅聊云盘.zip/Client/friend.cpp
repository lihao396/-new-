#include "friend.h"
#include "ui_friend.h"
#include "protocol.h"
#include "client.h"

#include <QInputDialog>
#include <QDebug>
#include <QMessageBox>

Friend::Friend(QWidget *parent) : QWidget(parent),ui(new Ui::Friend)
{
    ui->setupUi(this);
    m_pOnlineUser = new OnlineUser;
    m_pchat = new Chat;
    flushFriend();
}

Friend::~Friend()
{
    delete ui;
    delete m_pchat;
    delete m_pOnlineUser;
}

OnlineUser *Friend::getOnlineUser()
{
    return m_pOnlineUser;
}

Chat *Friend::getChat()
{
    return m_pchat;
}

//刷新用户
void Friend::flushFriend()
{
    PDU* pdu = mkPDU(0);//构建PDU
    pdu->uiMsgType = ENUN_MSG_TYPE_FLUSH_ONLINE_USER_REQUEST;
    memcpy(pdu->caData,Client::getInstance().m_strLoginName.toStdString().c_str(),32);
    Client::getInstance().sendPDU(pdu);
}

void Friend::updateFriendLW(QStringList friendList)
{
    ui->onlineFriend_LW->clear();       //清除
    ui->onlineFriend_LW->addItems(friendList);//添加friendList
}

QListWidget *Friend::getFriend_LW()
{
    return ui->onlineFriend_LW; //返回在线好友列表框中的在线好友
}

void Friend::on_findFriend_PB_clicked()
{
    QString name = QInputDialog::getText(this,"查找","用户名");
    if(name.isEmpty())//判断name是否为空
    {
        return;
    }
    PDU* pdu = mkPDU(0);//构建PDU
    pdu->uiMsgType = ENUN_MSG_TYPE_FIND_USER_REQUEST;
    memcpy(pdu->caData,name.toStdString().c_str(),32);
    Client::getInstance().sendPDU(pdu);
}


void Friend::on_online_PB_clicked()
{
    if(m_pOnlineUser->isHidden())//如果是隐藏的就展示出来
    {
        m_pOnlineUser->show();
    }

    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUN_MSG_TYPE_ONLINE_USER_REQUEST;
    Client::getInstance().sendPDU(pdu);
}

void Friend::on_flushFriend_PB_clicked()
{
    flushFriend();
}

void Friend::on_delFriend_PB_clicked()
{
   QListWidgetItem* dItem = ui->onlineFriend_LW->currentItem(); //获取当前列表框好友
   if(!dItem)   //没有选择要删除的好友
   {
       QMessageBox::information(this,"删除好友","未选择要删除的好友");
       return;
   }
   QString delName = dItem->text();
   int ret = QMessageBox::question(this,"删除好友",QString("是否删除当前好友 %1 ").arg(delName));
   if(ret != QMessageBox::Yes)
   {
       return;
   }
   PDU* pdu = mkPDU(0);
   pdu->uiMsgType = ENUN_MSG_TYPE_DELETE_USER_REQUEST;
   memcpy(pdu->caData,Client::getInstance().m_strLoginName.toStdString().c_str(),32);
   memcpy(pdu->caData + 32,delName.toStdString().c_str(),32);
   Client::getInstance().sendPDU(pdu);
}

void Friend::on_chat_PB_clicked()
{
    QListWidgetItem* pItem = ui->onlineFriend_LW->currentItem(); //获取当前列表框好友
    if(!pItem)  //判断是否选中在线好友
    {
        QMessageBox::information(this,"聊天","未选择要聊天的好友");
        return;
    }
    m_pchat->m_ChatName = pItem->text();    //初始化m_ChatName
    if(m_pchat->isHidden()) //判断聊天界面是否隐藏
    {
        m_pchat->show();
        m_pchat->setWindowTitle(m_pchat->m_ChatName);
    }
}
