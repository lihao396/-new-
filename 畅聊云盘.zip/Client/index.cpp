#include "client.h"
#include "index.h"
#include "ui_index.h"

Index::Index(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Index)
{
    ui->setupUi(this);
    setWindowTitle(Client::getInstance().m_strLoginName);
}

Index::~Index()
{
    delete ui;
}

//获取好友界面控件
Friend *Index::getFriend()
{
    return ui->friendPage;
}

//获取文件界面控件
File *Index::getFile()
{
    return ui->filePage;
}

//单例模式全局访问节点
Index &Index::getInstance()
{
    static Index instance;
    return instance;
}

void Index::on_friend_PB_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->file_PB->setStyleSheet("QPushButton{border:none;padding:20px;}");
    ui->friend_PB->setStyleSheet("QPushButton{border:none;background-color:rgb(0, 255, 0);padding:20px;}");
}

void Index::on_file_PB_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->file_PB->setStyleSheet("QPushButton{border:none;background-color:rgb(0, 255, 0);padding:20px;}");
    ui->friend_PB->setStyleSheet("QPushButton{border:none;padding:20px;}");
}
