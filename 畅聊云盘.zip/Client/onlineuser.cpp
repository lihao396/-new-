#include "onlineuser.h"
#include "ui_onlineuser.h"
#include "client.h"

#include <QDebug>

OnlineUser::OnlineUser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OnlineUser)
{
    ui->setupUi(this);
}

OnlineUser::~OnlineUser()
{
    delete ui;
}

void OnlineUser::updateOnlineUserWidgetList(QStringList userList)
{
    ui->onlineUser_LW->clear();
    ui->onlineUser_LW->addItems(userList);
}

void OnlineUser::on_onlineUser_LW_itemDoubleClicked(QListWidgetItem *item)
{
    //获取当前用户名 目标用户名
    QString strCurName = Client::getInstance().m_strLoginName;
    QString strTarName = item->text();
    qDebug() << "添加好友请求——当前：" <<  strCurName
             << "目标：" <<  strTarName;

    //构建pdu 发送给服务器
    PDU* pdu = mkPDU(0);
    pdu->uiMsgType = ENUN_MSG_TYPE_ADD_USER_REQUEST;
    memcpy(pdu->caData,strCurName.toStdString().c_str(),32);
    memcpy(pdu->caData + 32,strTarName.toStdString().c_str(),32);
    Client::getInstance().sendPDU(pdu);
}
