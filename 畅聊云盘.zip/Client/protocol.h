#ifndef PROTOCOL_H
#define PROTOCOL_H

typedef unsigned int uint;

//消息类型 枚举值：
enum ENUN_MSG_TYPE
{
    ENUN_MSG_TYPE_MIN = 0,//最小值
    ENUN_MSG_TYPE_REGIST_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_REGIST_RESPEND,//服务器给出响应

    //登录
    ENUN_MSG_TYPE_REGIST_REQUEST_login,//客户端发送请求_登录
    ENUN_MSG_TYPE_REGIST_RESPEND_login,//服务器给出响应_登录

    //查找用户
    ENUN_MSG_TYPE_FIND_USER_REQUEST,//客户端发送请求_查找用户
    ENUN_MSG_TYPE_FIND_USER_RESPEND,//服务器给出响应_查找用户

    //在线用户
    ENUN_MSG_TYPE_ONLINE_USER_REQUEST,//客户端发送请求_在线用户
    ENUN_MSG_TYPE_ONLINE_USER_RESPEND,//服务器给出响应_在线用户

    //添加用户
    ENUN_MSG_TYPE_ADD_USER_REQUEST,//客户端发送请求_添加用户
    ENUN_MSG_TYPE_ADD_USER_RESPEND,//服务器给出响应_添加用户

    //同意添加好友
    ENUN_MSG_TYPE_AGREE_USER_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_AGREE_USER_RESPEND,//服务器给出响应

    //刷新在线好友
    ENUN_MSG_TYPE_FLUSH_ONLINE_USER_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_FLUSH_ONLINE_USER_RESPEND,//服务器给出响应

    //删除好友
    ENUN_MSG_TYPE_DELETE_USER_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_DELETE_USER_RESPEND,//服务器给出响应

    //聊天
    ENUN_MSG_TYPE_CHAT_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_CHAT_RESPEND,//服务器给出响应

    //创建文件夹
    ENUN_MSG_TYPE_MKDIR_REQUEST,//客户端发送请求_查找用户
    ENUN_MSG_TYPE_MKDIR_RESPEND,//服务器给出响应_查找用户

    //刷新文件
    ENUN_MSG_TYPE_FLUSH_FILE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_FLUSH_FILE_RESPEND,//服务器给出响应

    //删除文件夹
    ENUN_MSG_TYPE_DELETE_FILEDIR_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_DELETE_FILEDIR_RESPEND,//服务器给出响应

    //重命名
    ENUN_MSG_TYPE_RENAME_FILE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_RENAME_FILE_RESPEND,//服务器给出响应

    //移动文件
    ENUN_MSG_TYPE_MOVE_FILE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_MOVE_FILE_RESPEND,//服务器给出响应

    //上传文件
    ENUN_MSG_TYPE_UPLOAD_FILE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_UPLOAD_FILE_RESPEND,//服务器给出响应

    //上传文件数据
    ENUN_MSG_TYPE_UPLOAD_FILE_DATA_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_UPLOAD_FILE_DATA_RESPEND,//服务器给出响应

    //分享文件
    ENUN_MSG_TYPE_SHARE_FILE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_SHARE_FILE_RESPEND,//服务器给出响应

    //接收文件同意
    ENUN_MSG_TYPE_SHARE_FILE_ARGEE_REQUEST,//客户端发送请求
    ENUN_MSG_TYPE_SHARE_FILE_ARGEE_RESPEND,//服务器给出响应

    ENUN_MSG_TYPE_MAX = 0x00fffff,//最大值
};

//协议数据单元结构体
struct PDU
{
    uint uiPDUlen;//协议数据PDU长度
    uint uiMsglen;//实际消息长度
    uint uiMsgType;//消息类型
    char caData[64];//参数
    char caMsg[];//实际消息
};

//文件信息结构体
struct FileInfo
{
    char caFileName[32];//文件名
    uint uiFileType;//文件类型
};
//构建结构体中的柔性数组
PDU *mkPDU(uint uiMsglen);


#endif // PROTOCOL_H
