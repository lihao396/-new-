#include "client.h"
#include "index.h"
#include "reshander.h"
#include "chat.h"

#include <QMessageBox>

ResHander::ResHander()
{

}

void ResHander::regist(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        QMessageBox::information(&Client::getInstance(),"注册","注册成功");
    }
    else
    {
        QMessageBox::information(&Client::getInstance(),"注册","注册失败");
    }
}

void ResHander::login(PDU *pdu)
{
    bool ret;
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        Index::getInstance().show();//登录后界面
        Client::getInstance().hide();//隐藏登录界面
    }
    else
    {
        QMessageBox::information(&Client::getInstance(),"登录","登录失败");
    }
}

void ResHander::findUser(PDU *pdu)
{
    int ret;
    char caName[32] = {'\0'};

    memcpy(caName,pdu->caData,32);
    memcpy(&ret,pdu->caData + 32,sizeof(int));

    //通过ret的值判断用户是否存在以及是否在线
    if(ret == -1)
    {
        QMessageBox::information(&Index::getInstance(),"查找",QString("%1 不存在").arg(caName));
    }
    else if(ret == 0)
    {
        QMessageBox::information(&Index::getInstance(),"查找",QString("%1 不在线").arg(caName));
    }
    else
    {
        int ret = QMessageBox::information(&Index::getInstance(),"查找",QString("%1 在线").arg(caName),"添加好友","取消");
        if(ret != 0)
        {
            return;
        }
        //构建pdu 发送给服务器
        PDU* pdu = mkPDU(0);
        pdu->uiMsgType = ENUN_MSG_TYPE_ADD_USER_REQUEST;
        memcpy(pdu->caData,Client::getInstance().m_strLoginName.toStdString().c_str(),32);
        memcpy(pdu->caData + 32,caName,32);
        Client::getInstance().sendPDU(pdu);
    }
}

void ResHander::onlineUser(PDU *pdu)
{
    uint uiSize = pdu->uiMsglen / 32;
    QStringList userList;
    userList.clear();
    char caTmp[32] = {'\0'};
    for(uint i = 0;i < uiSize;i++)
    {
        memcpy(caTmp,pdu->caMsg + i * 32,32);
        if(QString(caTmp) == Client::getInstance().m_strLoginName)
        {
            continue;
        }
        userList.append(QString(caTmp));
    }
    Index::getInstance().getFriend()->getOnlineUser()->updateOnlineUserWidgetList(userList);
}

void ResHander::addUser(PDU *pdu)
{
    int ret;
    memcpy(&ret,pdu->caData,sizeof(int));

    if(ret == -1)
    {
        QMessageBox::information(&Index::getInstance(),"添加用户","添加失败，服务器错误");
    }
    else if(ret == -2)
    {
        QMessageBox::information(&Index::getInstance(),"添加用户","用户已经是你的好友");
    }
    else if(ret == 0)
    {
        QMessageBox::information(&Index::getInstance(),"添加用户","对方不在线");
    }
}

void ResHander::addUserRequest(PDU *pdu)
{
    char caName[32] = {'\0'};
    memcpy(caName,pdu->caData,32);
    int ret = QMessageBox::question(&Index::getInstance(),"添加好友请求",QString("是否同意 %1 好友的添加请求").arg(caName));
    if(ret != QMessageBox::Yes)
    {
        return;
    }
    PDU * respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_AGREE_USER_REQUEST;
    memcpy(respdu->caData,pdu->caData,64);
    Client::getInstance().sendPDU(respdu);
}

void ResHander::addUserAgreeRequest(PDU *pdu)
{
    QMessageBox::information(&Index::getInstance(),"添加用户","添加成功");
    Index::getInstance().getFriend()->flushFriend(); //调用刷新好友函数
}

void ResHander::flushOnlineUser(PDU *pdu)
{
    uint uiSize = pdu->uiMsglen / 32;
    QStringList userList;
    userList.clear();
    char caTmp[32] = {'\0'};
    for(uint i = 0;i < uiSize;i++)
    {
        memcpy(caTmp,pdu->caMsg + i * 32,32);
        userList.append(QString(caTmp));
    }
    Index::getInstance().getFriend()->updateFriendLW(userList);
}

void ResHander::deleteUser(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        QMessageBox::information(&Index::getInstance(),"删除好友","删除成功");
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"删除好友","删除失败");
    }
    Index::getInstance().getFriend()->flushFriend();
}

void ResHander::chat(PDU *pdu)
{
    Chat* sh = Index::getInstance().getFriend()->getChat();

    char caChatName[32] = {'\0'};
    memcpy(caChatName,pdu->caData,32);
    sh->m_ChatName = caChatName;
    if(sh->isHidden())
    {
        sh->setWindowTitle(sh->m_ChatName);
        sh->show();
    }
    sh->update_TE(QString("%1 : %2").arg(caChatName).arg(pdu->caMsg));
}

void ResHander::mkDir(PDU *pdu)
{
    bool ret;
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(!ret)
    {
        QMessageBox::information(&Index::getInstance(),"新建文件夹","新建文件夹失败");
    }
    Index::getInstance().getFile()->flushFile();
}

void ResHander::flushFile(PDU *pdu)
{
    int iCount = pdu->uiMsglen / sizeof(FileInfo);
    QList<FileInfo*> pFileInfoList;
    for(int i = 0; i < iCount; i++)
    {
        FileInfo* pFileInfo = new FileInfo;
        memcpy(pFileInfo,pdu->caMsg + i * sizeof (FileInfo),sizeof (FileInfo));
        pFileInfoList.append(pFileInfo);
    }
    Index::getInstance().getFile()->updateFileList(pFileInfoList);
}

void ResHander::deleteFileDir(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        QMessageBox::information(&Index::getInstance(),"删除文件夹","删除成功");
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"删除文件夹","删除失败");
    }
    Index::getInstance().getFile()->flushFile();
}

void ResHander::renameFile(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        QMessageBox::information(&Index::getInstance(),"上传文件","上传文件成功");
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"上传文件","上传文件失败");
    }
    Index::getInstance().getFile()->flushFile();
}

void ResHander::moveFile(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(!ret)
    {
        QMessageBox::information(&Index::getInstance(),"移动文件","移动文件失败");
    }
    Index::getInstance().getFile()->flushFile();
}

void ResHander::uploadFile(PDU *pdu)
{
    int ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(int));
    if(ret == 0)
    {
        Index::getInstance().getFile()->myUploadFile();
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"上传文件","上传文件失败");
    }
}

void ResHander::uploadFileData(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(ret)
    {
        QMessageBox::information(&Index::getInstance(),"上传文件","上传文件成功");
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"上传文件","上传文件失败");
    }
    Index::getInstance().getFile()->flushFile();
}

void ResHander::shareFile()
{
    QMessageBox::information(&Index::getInstance(),"分享文件","文件已分享");
}

void ResHander::shareFileRequst(PDU *pdu)
{
    QString sharePath = QString(pdu->caMsg);
    int index = sharePath.lastIndexOf('/');
    QString fileName = sharePath.right(sharePath.size() - index - 1);

    QString newMsg = QString("%1 分享文件：%2\n是否接收").arg(pdu->caData).arg(fileName);
    int ret = QMessageBox::question(&Index::getInstance(),"分享文件",newMsg);
    if(ret != QMessageBox::Yes)
    {
        return;
    }

    //caData 存当前用户名，caMsg存分享文件的路径
    PDU* respdu = mkPDU(pdu->uiMsglen);
    respdu->uiMsgType = ENUN_MSG_TYPE_SHARE_FILE_ARGEE_REQUEST;
    QString strName = Client::getInstance().m_strLoginName;
    memcpy(respdu->caData,strName.toStdString().c_str(),32);
    memcpy(respdu->caMsg,pdu->caMsg,pdu->uiMsglen);
    Client::getInstance().sendPDU(respdu);
}

void ResHander::shareFileAgree(PDU *pdu)
{
    bool ret;   //接收服务器中cadata的结果
    memcpy(&ret,pdu->caData,sizeof(bool));
    if(!ret)
    {
        QMessageBox::information(&Index::getInstance(),"分享文件","分享文件失败");
    }
    else
    {
        QMessageBox::information(&Index::getInstance(),"分享文件","分享文件成功");
    }
    Index::getInstance().getFile()->flushFile();
}
