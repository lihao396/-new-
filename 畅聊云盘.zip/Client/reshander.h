#ifndef RESHANDER_H
#define RESHANDER_H

#include "protocol.h"



class ResHander
{
public:
    ResHander();

    void regist(PDU* pdu);      //处理注册
    void login(PDU* pdu);          //处理登录
    void findUser(PDU* pdu);        //处理查找好友
    void onlineUser(PDU* pdu);      //处理在线用户
    void addUser(PDU* pdu);         //处理添加好友
    void addUserRequest(PDU* pdu);         //处理好友转发
    void addUserAgreeRequest(PDU* pdu);     //处理同意好友转发
    void flushOnlineUser(PDU* pdu);      //刷新在线用户
    void deleteUser(PDU* pdu);      //删除用户
    void chat(PDU* pdu);      //聊天
    void mkDir(PDU* pdu);      //新建文件夹
    void flushFile(PDU* pdu);      //刷新文件夹
    void deleteFileDir(PDU* pdu);      //删除文件夹
    void renameFile(PDU* pdu);      //重命名文件
    void moveFile(PDU* pdu);      //移动文件
    void uploadFile(PDU* pdu);      //上传文件
    void uploadFileData(PDU* pdu);      //上传文件数据
    void shareFile();      //分享文件
    void shareFileRequst(PDU* pdu);      //发送接收文件请求
    void shareFileAgree(PDU* pdu);      //同意接收文件



};

#endif // RESHANDER_H
