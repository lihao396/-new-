#include "client.h"
#include "index.h"
#include "sharefile.h"
#include "ui_sharefile.h"

ShareFile::ShareFile(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ShareFile)
{
    ui->setupUi(this);
}

ShareFile::~ShareFile()
{
    delete ui;
}

void ShareFile::updateOnlineFriend_LW()
{
    ui->onlineFriend_LW->clear();
    QListWidget* friend_LW = Index::getInstance().getFriend()->getFriend_LW();
    for(int i = 0; i < friend_LW->count();i++)
    {
        QListWidgetItem* friendItem = friend_LW->item(i);
        QListWidgetItem* newItem = new QListWidgetItem(* friendItem);
        ui->onlineFriend_LW->addItem(newItem);
    }
}

void ShareFile::on_allSelect_PB_clicked()
{
    for(int i = 0;i < ui->onlineFriend_LW->count();i++)
    {
        ui->onlineFriend_LW->item(i)->setSelected(true);
    }
}

void ShareFile::on_cancelAllSelect_PB_clicked()
{
    for(int i = 0;i < ui->onlineFriend_LW->count();i++)
    {
        ui->onlineFriend_LW->item(i)->setSelected(false);
    }
}

//确认按钮
void ShareFile::on_ok_PB_clicked()
{
    //获取当前用户名、文件路径、分享文件名
    QString strCurName = Client::getInstance().m_strLoginName;
    QString strCurPath = Index::getInstance().getFile()->curPath;
    QString shareFileName = Index::getInstance().getFile()->shareFileName;

    //拼接当前路径和名字
    QString newPath = strCurPath + "/" + shareFileName;

    //得到好友列表中的所有好友
    QList<QListWidgetItem*> pItems = ui->onlineFriend_LW->selectedItems();

    //将当前用户名和好友数量放进caData中
    int friendSize = pItems.size();
    PDU* pdu = mkPDU(friendSize*32 + newPath.toStdString().size());
    pdu->uiMsgType = ENUN_MSG_TYPE_SHARE_FILE_REQUEST;

    memcpy(pdu->caData,strCurName.toStdString().c_str(),32);
    memcpy(pdu->caData+32,&friendSize,sizeof(int));

    for(int i = 0;i < friendSize;i++)
    {
        memcpy(pdu->caMsg + i*32,pItems.at(i)->text().toStdString().c_str(),32);
    }
    memcpy(pdu->caMsg + friendSize*32,newPath.toStdString().c_str(),newPath.toStdString().size());
    Client::getInstance().sendPDU(pdu);
}
