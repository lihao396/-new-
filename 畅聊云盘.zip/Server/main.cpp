#include "server.h"

#include <QApplication>
#include "operatedb.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    OperateDB::getInstance().connect();//连接数据库
    Server::getInstance();
    return a.exec();
}
