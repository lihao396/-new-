#include "msghandler.h"
#include "operatedb.h"
#include "mytcpsocket.h"
#include "mytcpserver.h"
#include "server.h"

#include <QDebug>
#include <QDir>

MsgHandler::MsgHandler()
{
    Uploading = false;
}

//注册
PDU *MsgHandler::regist(PDU *pdu)
{
    char caName[32] = {'\0'};
    char caPwd[32] = {'\0'};
    memcpy(caName,pdu->caData,32);      //取出用户名
    memcpy(caPwd,pdu->caData + 32,32);   //取出密码
    qDebug() << "\n\nrecvMsg regist caName:" << caName
             << "        caPwd:"  << caPwd;
    //调用单例模式数据库函数
    bool ret = OperateDB::getInstance().handleRegist(caName,caPwd);
    if(ret)
    {
        QDir dir;
        dir.mkdir(QString("%1/%2").arg(Server::getInstance().m_strRoot).arg(caName));
    }
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_REGIST_RESPEND;
    memcpy(respdu->caData,&ret,sizeof(bool));       //ret放到cadata中
    return respdu;
}

//登录
PDU *MsgHandler::login(PDU *pdu, QString &loginName)
{
    char caName[32] = {'\0'};
    char caPwd[32] = {'\0'};
    memcpy(caName,pdu->caData,32);
    memcpy(caPwd,pdu->caData + 32,32);
    qDebug() << "\n\nrecvMsg login caName:" << caName
             << "        login caPwd:"  << caPwd;

    bool ret = OperateDB::getInstance().handlelogin(caName,caPwd);
    if(ret)
    {
        loginName = caName;
    }
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_REGIST_RESPEND_login;
    memcpy(respdu->caData,&ret,sizeof(bool));
    return respdu;
}

//查找用户
PDU *MsgHandler::findUser(PDU* pdu)
{
    char caName[32] = {'\0'};
    memcpy(caName,pdu->caData,32);
    qDebug() << "\n\nrecvMsg find_user caName:" << caName;

    int ret = OperateDB::getInstance().handleFindUser(caName);

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_FIND_USER_RESPEND;
    memcpy(respdu->caData,caName,32);
    memcpy(respdu->caData + 32,&ret,sizeof(int));
    return respdu;
}

//在线用户
PDU* MsgHandler::onlineUser()
{
    QStringList res = OperateDB::getInstance().handleOnlineUser();
    uint uiMsgLen = res.size() * 32;
    PDU* respdu = mkPDU(uiMsgLen);
    respdu->uiMsgType = ENUN_MSG_TYPE_ONLINE_USER_RESPEND;
    for(int i = 0;i < res.size();i++)
    {
        memcpy(respdu->caMsg + i * 32,res.at(i).toStdString().c_str(),32);
    }
    return respdu;
}

//添加好友
PDU *MsgHandler::addUser(PDU *pdu)
{
    char caCurName[32] = {'\0'};
    char caTarName[32] = {'\0'};
    memcpy(caCurName,pdu->caData,32);
    memcpy(caTarName,pdu->caData + 32,32);
    qDebug() << "\n\nrecvMsg addUser caCurName:" << caCurName
             << "        caTarName:"  << caTarName;
    //调用单例模式数据库函数
    int ret = OperateDB::getInstance().handleAddUser(caCurName,caTarName);

    qDebug() << "handleAddUser ret: " << ret;

    if(ret == 1)
    {
        MyTcpServer::getInstance().resend(caTarName,pdu);
    }
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_ADD_USER_RESPEND;
    memcpy(respdu->caData,&ret,sizeof(int));       //ret放到cadata中
    return respdu;
}

//同意添加好友
PDU *MsgHandler::addUserAgree(PDU *pdu)
{
    char caCurName[32] = {'\0'};
    char caTarName[32] = {'\0'};
    memcpy(caCurName,pdu->caData,32);
    memcpy(caTarName,pdu->caData + 32,32);
    qDebug() << "\n\nrecvMsg addUserAgree caCurName:" << caCurName
             << "        caTarName:"  << caTarName;
    //调用单例模式数据库函数
    OperateDB::getInstance().handleAgreeAddUser(caCurName,caTarName);

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_AGREE_USER_RESPEND;
    MyTcpServer::getInstance().resend(caCurName,respdu);
    return respdu;
}

//刷新在线用户好友
PDU *MsgHandler::FlushOnlineUser(PDU* pdu)
{
    char caName[32] = {'\0'};
    memcpy(caName,pdu->caData,32);
    qDebug() << "\n\nrecvMsg FlushOnlineUser caName:" << caName;
    QStringList res = OperateDB::getInstance().handleFlushOnlineUser(caName);
    uint uiMsgLen = res.size() * 32;
    PDU* respdu = mkPDU(uiMsgLen);
    respdu->uiMsgType = ENUN_MSG_TYPE_FLUSH_ONLINE_USER_RESPEND;
    for(int i = 0;i < res.size();i++)
    {
        memcpy(respdu->caMsg + i * 32,res.at(i).toStdString().c_str(),32);
    }
    return respdu;
}

//删除好友
PDU *MsgHandler::deleteUser(PDU *pdu)
{
    char caCurName[32] = {'\0'};
    char caTarName[32] = {'\0'};
    memcpy(caCurName,pdu->caData,32);
    memcpy(caTarName,pdu->caData + 32,32);
    qDebug() << "\n\nrecvMsg deleteUser caCurName:" << caCurName
             << "        caTarName:"  << caTarName;
    bool ret = OperateDB::getInstance().handleDeleteUser(caCurName,caTarName);
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_DELETE_USER_RESPEND;
    memcpy(respdu->caData,&ret,sizeof(bool));       //ret放到cadata中
    return respdu;
}

//聊天
void MsgHandler::chat(PDU *pdu)
{
    char caTarName[32] = {'\0'};
    memcpy(caTarName,pdu->caData +32,32);
    MyTcpServer::getInstance().resend(caTarName,pdu);
}

//新建文件夹
PDU *MsgHandler::mkDir(PDU *pdu)
{
    QString curPath = pdu->caMsg;
    char caNewDir[32] = {'\0'};
    memcpy(caNewDir,pdu->caData,32);

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_MKDIR_RESPEND;

    bool res = false;
    QDir dir;

    QString newPath = QString("%1/%2").arg(curPath).arg(caNewDir);

    //如果当前路径不存在、或者要创建的文件夹已经催存在、创建文件夹失败，返回错误
    if(!dir.exists(curPath) || dir.exists(newPath) || !dir.mkdir(newPath))
    {
        memcpy(respdu->caData,&res,sizeof(bool));
        return respdu;
    }
    res = true; //成功
    memcpy(respdu->caData,&res,sizeof(bool));
    return respdu;
}

PDU *MsgHandler::flushFile(PDU *pdu)
{
    char* pCurPath = pdu->caMsg;
    QDir dir(pCurPath);
    QFileInfoList fileInfoList = dir.entryInfoList();
    int fileCount = fileInfoList.size();    //计算一个camsg(文件类型+文件名)大小

    qDebug() << "flushFile fileCount" << fileCount;

    PDU* respdu = mkPDU((fileCount-2)* sizeof(FileInfo));
    respdu->uiMsgType = ENUN_MSG_TYPE_FLUSH_FILE_RESPEND;

    FileInfo* pFileInfo = NULL;
    QString fileName;

    for(int i = 0,j = 0; i < fileCount; i++)
    {
        fileName = fileInfoList[i].fileName();  //获取列表框中的名字
        if(fileName == QString(".") || fileName == QString(".."))
        {
            continue;
        }
        pFileInfo = (FileInfo*)respdu->caMsg + j++;   //文件偏移一个FileInfo大小

        memcpy(pFileInfo->caFileName,fileName.toStdString().c_str(),32);
        if(fileInfoList[i].isDir())
        {
            pFileInfo->uiFileType = 0;  //文件夹
        }
        else if(fileInfoList[i].isFile())
        {
            pFileInfo->uiFileType = 1;  //普通文件
        }

        qDebug() << "flushFile fileName" << fileName;

    }

    return respdu;
}

PDU *MsgHandler::deleteFileDir(PDU *pdu)
{
    char* pCurPath = pdu->caMsg;
    QFileInfo fileInfo(pCurPath);
    bool ret = false;
    if(fileInfo.isDir())
    {
        QDir dir(pCurPath);
        ret = dir.removeRecursively();  //删除文件夹
    }
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_DELETE_FILEDIR_RESPEND;
    memcpy(respdu->caData,&ret,sizeof(bool));       //ret放到cadata中
    return respdu;
}

PDU *MsgHandler::renameFile(PDU *pdu)
{
    char* pCurPath = pdu->caMsg;
    char oldName[32] = {'\0'};
    char newName[32] = {'\0'};
    memcpy(oldName,pdu->caData,32);
    memcpy(newName,pdu->caData + 32,32);

    QDir dir;
    QString oldPath = QString("%1/%2").arg(pCurPath).arg(oldName);
    QString newPath = QString("%1/%2").arg(pCurPath).arg(newName);

    bool res = dir.rename(oldPath,newPath);

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_RENAME_FILE_RESPEND;
    memcpy(respdu->caData,&res,sizeof(bool));
    return respdu;
}

PDU *MsgHandler::moveFile(PDU *pdu)
{
    int srcLen = 0;
    int tarLen = 0;

    memcpy(&srcLen,pdu->caData,sizeof(int));
    memcpy(&tarLen,pdu->caData + 32,sizeof(int));

    char* srcPath = new char[srcLen + 1];
    char* tarPath = new char[tarLen + 1];

    memset(srcPath,'\0',srcLen + 1);
    memset(tarPath,'\0',tarLen + 1);

    memcpy(srcPath,pdu->caMsg,srcLen);
    memcpy(tarPath,pdu->caMsg + srcLen,tarLen);

    bool res = QFile::rename(srcPath,tarPath);

    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_MOVE_FILE_RESPEND;
    memcpy(respdu->caData,&res,sizeof(bool));

    delete [] srcPath;
    delete [] tarPath;
    srcPath = NULL;
    tarPath = NULL;

    return respdu;
}

PDU *MsgHandler::uploadFile(PDU *pdu)
{
    qDebug() << "uploadFile start\n";
    PDU* respdu = mkPDU(0);
    int ret = 0;
    respdu->uiMsgType = ENUN_MSG_TYPE_UPLOAD_FILE_RESPEND;
    if(Uploading)   //如果正在上传文件
    {
        qDebug() << "uploadFile ret is true";
        ret = 1;
        memcpy(respdu->caData,&ret,sizeof(int));
        return respdu;
    }

    char fileName[32] = {'\0'};
    qint64 fileSize = 0;

    memcpy(fileName,pdu->caData,32);
    memcpy(&fileSize,pdu->caData+32,sizeof(qint64));
    QString strPath = QString("%1/%2").arg(pdu->caMsg).arg(fileName);   //拼接当前路径和文件名作为路径
    uploadFileObject.setFileName(strPath);
    if(uploadFileObject.open(QIODevice::WriteOnly)) //如果以只写打开上传文件对象的文件成功就更新上传属性
    {
          Uploading = true; //正在上传
          uploadFileSize = fileSize;    //上传文件大小为 fileSize
          alreadyUploadSize = 0;    //已经上传的文件大小为 0
    }
    else
    {
        qDebug() <<"file open failed";  //文件打开失败
        ret = -1;
    }

    memcpy(respdu->caData,&ret,sizeof(int));
    qDebug() << "Uploading；" << Uploading
             << "uploadFileSize：" << uploadFileSize
             << "alreadyUploadSize：\n" << alreadyUploadSize;

    qDebug() << "uploadFile end\n";

    return respdu;
}

PDU *MsgHandler::uploadFileData(PDU *pdu)
{
    uploadFileObject.write(pdu->caMsg,pdu->uiMsglen);
    alreadyUploadSize += pdu->uiMsglen;
    if(alreadyUploadSize < uploadFileSize)
    {
        return NULL;
    }

    uploadFileObject.close();
    Uploading = false;
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_UPLOAD_FILE_DATA_RESPEND;
    bool ret = alreadyUploadSize == uploadFileSize;
    memcpy(respdu->caData,&ret,sizeof(bool));
    return respdu;
}

PDU *MsgHandler::shareFile(PDU *pdu)
{
    char strCurName[32] = {'\0'};
    int friendsize = 0;
    memcpy(strCurName,pdu->caData,32);
    memcpy(&friendsize,pdu->caData+32,32);

    int size = friendsize * 32;
    PDU* resendPDU = mkPDU(pdu->uiMsglen - size);
    resendPDU->uiMsgType = pdu->uiMsgType;
    memcpy(resendPDU->caData,strCurName,32);
    memcpy(resendPDU->caMsg,pdu->caMsg + size,pdu->uiMsglen - size);
    qDebug() << "shareFile friend_num" << friendsize;

    //转发给接收的好友
    char friendName[32] = {'\0'};
    for(int i = 0;i < friendsize;i++)
    {
        memcpy(friendName,pdu->caMsg + i*32,32);
        qDebug() << "caRecvName" << friendName;
        MyTcpServer::getInstance().resend(friendName,resendPDU);
    }
    free(resendPDU);
    resendPDU = NULL;
    PDU* respdu = mkPDU(0);
    respdu->uiMsgType = ENUN_MSG_TYPE_SHARE_FILE_RESPEND;
    return  respdu;
}

PDU *MsgHandler::shareFileAgree(PDU *pdu)
{
    QString recvPath = QString("%1/%2").arg(Server::getInstance().m_strRoot).arg(pdu->caData);
    QString sharePath = pdu->caMsg;

    int index = sharePath.lastIndexOf('/');
    QString fileName = sharePath.right(sharePath.size() - index - 1);
    recvPath = recvPath + '/' + fileName;

    QFileInfo fileInfo(sharePath);
    int ret = true;
    if(fileInfo.isFile())
    {
        ret = QFile::copy(sharePath,recvPath);
    }
    else if(fileInfo.isDir())
    {
        //复制目录
    }
     PDU* respdu = mkPDU(0);
     respdu->uiMsgType = ENUN_MSG_TYPE_SHARE_FILE_ARGEE_RESPEND;
     memcpy(respdu->caData,&ret,sizeof(bool));
     return respdu;
}
