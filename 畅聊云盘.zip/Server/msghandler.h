#ifndef MSGHANDLER_H
#define MSGHANDLER_H

#include "protocol.h"

#include <QFile>
#include <QString>



class MsgHandler
{
public:
    MsgHandler();
    PDU* regist(PDU* pdu);

    PDU* login(PDU* pdu,QString& loginName);
    PDU* findUser(PDU* pdu);
    PDU *onlineUser();
    PDU* addUser(PDU* pdu);
    PDU* addUserAgree(PDU* pdu);
    PDU* FlushOnlineUser(PDU* pdu);
    PDU* deleteUser(PDU* pdu);
    void chat(PDU* pdu);

    PDU* mkDir(PDU* pdu);
    PDU* flushFile(PDU* pdu);
    PDU* deleteFileDir(PDU* pdu);
    PDU* renameFile(PDU* pdu);
    PDU* moveFile(PDU* pdu);
    PDU* uploadFile(PDU* pdu);
    PDU* uploadFileData(PDU* pdu);
    PDU* shareFile(PDU* pdu);
    PDU* shareFileAgree(PDU* pdu);


    QString m_strLoginName;

    QFile uploadFileObject; //上传文件对象
    bool Uploading; //是否正在上传
    qint64 uploadFileSize;  //上传文件大小
    qint64 alreadyUploadSize;   //已经上传文件大小
};

#endif // MSGHANDLER_H
