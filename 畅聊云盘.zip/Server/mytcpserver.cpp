#include "mytcpserver.h"

MyTcpServer &MyTcpServer::getInstance()
{
    static MyTcpServer instance;
    return instance;
}

void MyTcpServer::incomingConnection(qintptr handle)
{
    qDebug() << "新客户端连接";
    //将连接的客户端socket存入socket列表
    MyTcpSocket* pTcpSocket = new MyTcpSocket;
    pTcpSocket->setSocketDescriptor(handle);//进行初始化，设置socket描述符
    m_tcpSocketList.append(pTcpSocket);

    //连接移除socket的槽函数
    connect(pTcpSocket,&MyTcpSocket::offline,this,&MyTcpServer::deletesocket);
}

void MyTcpServer::resend(char *strName, PDU *pdu)
{
    if(strName == NULL || pdu == NULL)
    {
        return;
    }

    for(int i = 0;i < m_tcpSocketList.size();i++)
    {
        if(m_tcpSocketList.at(i)->m_strLoginName == strName)
        {
            qDebug() << "resend strName: " << strName;
            m_tcpSocketList.at(i)->write((char*)pdu,pdu->uiPDUlen);
            break;
        }
    }
}

void MyTcpServer::deletesocket(MyTcpSocket *mysocket)
{
    m_tcpSocketList.removeOne(mysocket);
    mysocket->deleteLater();//延迟释放
    mysocket = NULL;

    //测试登录在线情况
//    qDebug() << "在线数量："  << m_tcpSocketList.size();
//    for(int i = 0; i < m_tcpSocketList.size(); i++)
//    {
//        qDebug() << "在线名称：" << m_tcpSocketList.at(i)->m_strLoginName;
//    }
}

MyTcpServer::MyTcpServer()
{

}
