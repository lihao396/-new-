#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H

#include "mytcpsocket.h"
#include <QObject>
#include <QTcpServer>


class MyTcpServer : public QTcpServer
{
    Q_OBJECT
public:
    //获取实例
    static MyTcpServer& getInstance();
    //有客户端链接就会调用incomingConnection函数    handle：连接客户端的句柄
    void incomingConnection(qintptr handle);//重写函数

    void resend(char* strName,PDU* pdu);

private:
    MyTcpServer();
    //有新客户端连接就把socket指针存放在列表中
    QList<MyTcpSocket*> m_tcpSocketList;

public slots:
    void deletesocket(MyTcpSocket* mysocket);

};

#endif // MYTCPSERVER_H
