#include "mytcpsocket.h"
#include "protocol.h"
#include "operatedb.h"
#include <QDebug>

MyTcpSocket::MyTcpSocket()
{
    mh = new MsgHandler;
    //服务器接收的信号槽
    connect(this,&QTcpSocket::readyRead,this,&MyTcpSocket::recvMsg);
    connect(this,&QTcpSocket::disconnected,this,&MyTcpSocket::clientOffline);
}

PDU *MyTcpSocket::readPDU()
{
    uint uiPDULen = 0;
    //read：接收    读取协议总长度uiPDULen
    this->read((char*)&uiPDULen,sizeof(uint));
    uint uiMsgLen = uiPDULen - sizeof(PDU);     //实际消息长度
    PDU* pdu = mkPDU(uiMsgLen);
    //读取协议除了协议总长度以外的内容
    this->read((char*)pdu + sizeof(uint),uiPDULen - sizeof(uint));
    qDebug() << "recvMsg 消息类型：" << pdu->uiMsgType
             << "参数内容1：" << pdu->caData
             << "参数内容2：" << pdu->caData + 32
             << "消息内容：" << pdu->caMsg;
    return pdu;
}

//处理消息类型
PDU *MyTcpSocket::handlePDU(PDU *pdu)
{

    PDU* respdu = NULL;

    qDebug() << "recvMsg 消息类型：" << pdu->uiMsgType
             << "参数内容1：" << pdu->caData
             << "参数内容2：" << pdu->caData + 32
             << "消息内容：" << pdu->caMsg;

    switch(pdu->uiMsgType)
    {

        //注册
        case ENUN_MSG_TYPE_REGIST_REQUEST:
        {
            return mh->regist(pdu);
        }

        //登录
        case ENUN_MSG_TYPE_REGIST_REQUEST_login:
        {
             return mh->login(pdu,m_strLoginName);
        }

        //查找用户
        case ENUN_MSG_TYPE_FIND_USER_REQUEST:
        {
             return mh->findUser(pdu);
        }

        //在线用户
        case ENUN_MSG_TYPE_ONLINE_USER_REQUEST:
        {
             return mh->onlineUser();
        }

        //添加好友
        case ENUN_MSG_TYPE_ADD_USER_REQUEST:
        {
             return mh->addUser(pdu);
        }

        //添加好友同意
        case ENUN_MSG_TYPE_AGREE_USER_REQUEST:
        {
             return mh->addUserAgree(pdu);
        }

        //刷新在线用户
        case ENUN_MSG_TYPE_FLUSH_ONLINE_USER_REQUEST:
        {
             return mh->FlushOnlineUser(pdu);
        }

        //删除好友
        case ENUN_MSG_TYPE_DELETE_USER_REQUEST:
        {
             return mh->deleteUser(pdu);
        }

        //聊天
        case ENUN_MSG_TYPE_CHAT_REQUEST:
        {
            mh->chat(pdu);
            break;
        }

        //新建文件夹
        case ENUN_MSG_TYPE_MKDIR_REQUEST:
        {
            return mh->mkDir(pdu);
        }

        //刷新文件夹
        case ENUN_MSG_TYPE_FLUSH_FILE_REQUEST:
        {
            return mh->flushFile(pdu);
        }

        //删除文件夹
        case ENUN_MSG_TYPE_DELETE_FILEDIR_REQUEST:
        {
            return mh->deleteFileDir(pdu);
        }

        //重命名
        case ENUN_MSG_TYPE_RENAME_FILE_REQUEST:
        {
            return mh->renameFile(pdu);
        }

        //移动文件
        case ENUN_MSG_TYPE_MOVE_FILE_REQUEST:
        {
            return mh->moveFile(pdu);
        }

        //上传文件
        case ENUN_MSG_TYPE_UPLOAD_FILE_REQUEST:
        {
            return mh->uploadFile(pdu);
        }

        //上传文件数据
        case ENUN_MSG_TYPE_UPLOAD_FILE_DATA_REQUEST:
        {
            return mh->uploadFileData(pdu);
        }

        //分享文件
        case ENUN_MSG_TYPE_SHARE_FILE_REQUEST:
        {
            return mh->shareFile(pdu);
        }

        //接收文件同意
        case ENUN_MSG_TYPE_SHARE_FILE_ARGEE_REQUEST:
        {
            return mh->shareFileAgree(pdu);
        }



        default:
            break;
    }
    return respdu;
}

MyTcpSocket::~MyTcpSocket()
{
    delete mh;
}

void MyTcpSocket::sendPDU(PDU *pdu)
{
    if(pdu == NULL)
    {
        return;
    }
    write((char*)pdu,pdu->uiPDUlen);
    free(pdu);
    pdu = NULL;
}


void MyTcpSocket::recvMsg()
{
    qDebug() << "\nrecvMsg 接收的消息长度" << this->bytesAvailable();
    //定义一个buffer记录半包
    QByteArray data = this->readAll();
    buffer.append(data);
    //循环处理粘包问题
    while(buffer.size() >= int(sizeof(PDU)))
    {
        //判断buffer里是否含有一个完整的PDU结构体
        PDU* pdu = (PDU*)buffer.data();
        //半包
        if(buffer.size() < int(pdu->uiPDUlen))
        {
            break;
        }
        PDU* pdun = mkPDU(pdu->uiMsglen);
        memcpy(pdun,pdu,pdu->uiPDUlen);
        sendPDU(handlePDU(pdun));
        //将处理完的数据从buffer中移除
        buffer.remove(0,pdu->uiPDUlen);
    }
}


void MyTcpSocket::clientOffline()
{
    OperateDB::getInstance().handleOffline(m_strLoginName.toStdString().c_str());
    emit offline(this);
}










