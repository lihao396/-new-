#ifndef MYTCPSOCKET_H
#define MYTCPSOCKET_H

#include "protocol.h"
#include "msghandler.h"

#include <QObject>
#include <QTcpSocket>

class MyTcpSocket : public QTcpSocket
{
    Q_OBJECT
public:
    MyTcpSocket();
    QString m_strLoginName;

    PDU* readPDU();
    PDU* handlePDU(PDU* pdu);//处理消息类型
    MsgHandler * mh;
    ~MyTcpSocket();
    void sendPDU(PDU* pdu);
    QByteArray buffer;
public slots:

    void recvMsg();         //接收客户端发送的消息
    void clientOffline();

signals:
    void offline(MyTcpSocket *socket);
};

#endif // MYTCPSOCKET_H
