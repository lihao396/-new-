#include "operatedb.h"
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>

OperateDB &OperateDB::getInstance()
{
    static OperateDB instance;  //静态局部变量的实例
    return instance;
}

//连接数据库
void OperateDB::connect()
{
    m_db.setHostName("localhost");  //数据库地址
    m_db.setDatabaseName("mydb09");   //数据库名字
    m_db.setPort(3306);             //数据库端口号
    m_db.setUserName("root");       //用户名
    m_db.setPassword("123456");     //密码
    if(m_db.open())//打开数据库
    {
        qDebug() << "打开数据库成功";
    }
    else
    {
        qDebug() << "打开数据库失败" << m_db.lastError().text();//打印报错信息
    }
}

OperateDB::~OperateDB()
{
    m_db.close();
}
//注册
bool OperateDB::handleRegist(char *name, char *pwd)
{
    //查询用户名或者密码存不存在
    if(name == NULL || pwd == NULL)
    {
        return false;
    }
    //查询用户是否存在
    QString sql = QString("select * from user_info where name = '%1'").arg(name);//arg：将name替换成%1

    QSqlQuery q;
    if(!q.exec(sql) || q.next())//exec：执行sql语句  next：调用一次取出一条数据
    {
        return false;
    }
    //如果用户不存在则插入数据
    sql = QString("insert into user_info(name,pwd) values('%1','%2')").arg(name).arg(pwd);
    return q.exec(sql);
}

//登录
bool OperateDB::handlelogin(char *name, char *pwd)
{
    if(name == NULL || pwd == NULL)
    {
        return false;
    }
    QString sql = QString("select * from user_info where name = '%1' and pwd = '%2'").arg(name).arg(pwd);

    QSqlQuery q;
    if(!q.exec(sql) || !q.next())
    {
        return false;
    }
    //将用户在线字段改为1
    sql = QString("update user_info set online = 1 where name = '%1' and pwd = '%2'").arg(name).arg(pwd);
    return q.exec(sql);
}

//在线
void OperateDB::handleOffline(const char *name)
{
    if(name == NULL)
    {
        return;
    }
    //将online置为0
    QSqlQuery q;
    QString sql = QString("update user_info set online = 0 where name = '%1'").arg(name);
    q.exec(sql);
}

//查找用户
int OperateDB::handleFindUser(const char *name)
{
    if(name == NULL)
    {
        return -1;
    }
    QSqlQuery q;
    QString sql = QString("select online from user_info where name = '%1'").arg(name);
    q.exec(sql);
    if(!q.next())
    {
        return -1;
    }
    return q.value(0).toInt();//取出上面sql语句的执行结果 0：离线   1：在线
}

//在线用户
QStringList OperateDB::handleOnlineUser()
{
    QSqlQuery q;
    QString sql = QString("select name from user_info where online = 1");
    q.exec(sql);
    QStringList res;
    res.clear();
    while(q.next())
    {
        res.append(q.value(0).toString());
    }
    return res;
}

//添加好友
int OperateDB::handleAddUser(char *curName, char *tarName)
{
    if(curName == NULL || tarName == NULL)
    {
        return -1;
    }
    QString sql = QString(R"(
                          select * from friend
                          where
                            (
                              user_id=(select id from user_info where name = '%1')
                              and
                              friend_id=(select id from user_info where name = '%2')
                            )
                            or
                            (
                              friend_id=(select id from user_info where name = '%3')
                              and
                              user_id=(select id from user_info where name = '%4')
                            );
                          )").arg(curName).arg(tarName).arg(curName).arg(tarName);
    QSqlQuery q;
    q.exec(sql);
    if(q.next())
    {
        return -2;
    }
    sql = QString("select online from user_info where name = '%1'").arg(tarName);
    q.exec(sql);
    if(!q.next())
    {
        return -1;
    }
    return q.value(0).toInt();//取出上面sql语句的执行结果 0：离线   1：在线
}

//处理同意添加好友
void OperateDB::handleAgreeAddUser(char *curName, char *tarName)
{
    if(curName == NULL || tarName == NULL)
    {
        return;
    }
    QString sql = QString(R"(
                    insert into friend(user_id,friend_id)
                        select u1.id,u2.id from user_info u1,user_info u2
                        where u1.name = '%1' and u2.name = '%2'
                    )").arg(curName).arg(tarName);
    QSqlQuery q;
    q.exec(sql);
}

QStringList OperateDB::handleFlushOnlineUser(char *curName)
{
    QStringList res;
    res.clear();
    if(curName == NULL)
    {
        return res;
    }
    QSqlQuery q;
    QString sql = QString(R"(
                      select name from user_info
                          where id in (
                          select user_id from friend where friend_id = (select id from user_info where name = '%1')
                          union
                          select friend_id from friend where user_id = (select id from user_info where name = '%1')
                          ) and online = 1
                          )").arg(curName);
    q.exec(sql);
    while(q.next())
    {
        res.append(q.value(0).toString());
    }
    return res;
}

bool OperateDB::handleDeleteUser(char *curName, char *tarName)
{
    if(curName == NULL || tarName == NULL)
    {
        return false;
    }
    QString friendWhere = QString(R"(
                        user_id = (select id from user_info where name = '%1')
                          and
                          friend_id = (select id from user_info where name = '%2')
                          or
                          friend_id = (select id from user_info where name = '%1')
                            and
                            user_id = (select id from user_info where name = '%2')
                          )").arg(curName).arg(tarName);
    QString sql = QString("select * from friend where %1").arg(friendWhere);
    QSqlQuery q;
    q.exec(sql);
    if(!q.next())
    {
        return false;
    }
    sql = QString("delete from friend where %1").arg(friendWhere);
    return q.exec(sql);
}


//连接服务器
OperateDB::OperateDB(QObject *parent) : QObject(parent)
{
    m_db = QSqlDatabase::addDatabase("QMYSQL");//初始化m_db 添加MySQL的驱动
}
