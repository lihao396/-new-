#ifndef OPERATEDB_H
#define OPERATEDB_H

#include <QObject>
#include <QSqlDatabase>

class OperateDB : public QObject
{
    Q_OBJECT
public:

    QSqlDatabase m_db;      //数据库对象
    static OperateDB& getInstance();
    void connect();
    ~OperateDB();

    bool handleRegist(char* name,char* pwd);    //处理注册
    bool handlelogin(char* name,char* pwd);        //处理登录
    void handleOffline(const char* name);       //处理在线
    int handleFindUser(const char* name);       //处理查找用户
    QStringList handleOnlineUser();             //处理在线用户
    int handleAddUser(char* curName,char* tarName); //处理添加好友
    void handleAgreeAddUser(char* curName,char* tarName); //处理同意添加好友
    QStringList handleFlushOnlineUser(char* curName);    //刷新在线好友         //处理在线用户
    bool handleDeleteUser(char* curName,char* tarName);      //删除好友

private:
    //单例模式
    explicit OperateDB(QObject *parent = nullptr);
    OperateDB(const OperateDB& instance) = delete;
    OperateDB& operator=(const OperateDB&) = delete;
signals:

};

#endif // OPERATEDB_H
