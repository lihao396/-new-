#include "protocol.h"
#include <stdlib.h>
#include <string.h>

PDU *mkPDU(uint uiMsglen)
{
    uint uiPDULen = sizeof(PDU) + uiMsglen;//申请空间的总长度 = 协议总长度 + 申请的空间大小
    PDU* pdu = (PDU*)malloc(uiPDULen);
    if(pdu == NULL)//判空
    {
        exit(1);
    }
    memset(pdu,0,uiPDULen);//初始化pdu
    //赋值
    pdu->uiPDUlen = uiPDULen;
    pdu->uiMsglen = uiMsglen;
    return pdu;
}
