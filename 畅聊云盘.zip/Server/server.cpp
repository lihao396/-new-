#include "server.h"
#include "ui_server.h"
#include "mytcpserver.h"
#include <QFile>
#include <QDebug>


Server::Server(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Server)
{
    ui->setupUi(this);
    loadConfig();
    //使用listen监听客户端是否连接服务器
    MyTcpServer::getInstance().listen(QHostAddress(m_strIP),m_usPort);
}

Server::~Server()
{
    delete ui;
}

void Server::loadConfig()
{
    //新建一个QFile对象
    QFile file(":/server.config");//固定冒号开头
    //以只读打开文件
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray baData = file.readAll();
        QString strData = QString(baData);
        QStringList strList = strData.split("\r\n");
        m_strIP = strList.at(0);
        m_usPort = strList.at(1).toUShort();
        m_strRoot = strList.at(2);
        qDebug() << "打开配置文件 ip:" << m_strIP << "port:" << m_usPort << "m_strRoot" << m_strRoot;
        file.close();
    }
    else
    {
        qDebug() << "打开配置失败";
    }
}

Server &Server::getInstance()
{
    static Server instance;
    return instance;
}

